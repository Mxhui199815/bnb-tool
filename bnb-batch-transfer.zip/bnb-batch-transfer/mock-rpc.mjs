// 本地 mock BSC RPC: 用于离线测试发送链路与合约调用, 不连真实网络 (支持 JSON-RPC 批量请求)
import http from "node:http";
import { keccak256, toBeHex, Interface } from "ethers";

let blockNumber = 1000;
const txs = new Map(); // hash -> raw
const toHexQty = (n) => "0x" + BigInt(n).toString(16);

const tokenIface = new Interface([
  "function balanceOf(address) view returns (uint256)",
  "function allowance(address,address) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
]);
const routerIface = new Interface([
  "function getAmountsOut(uint amountIn, address[] path) view returns (uint[] amounts)",
]);

const receiptFor = (hash) => ({
  transactionHash: hash,
  transactionIndex: "0x0",
  blockHash: "0x" + "bb".repeat(32),
  blockNumber: toHexQty(blockNumber),
  from: "0x0000000000000000000000000000000000000001",
  to: "0x0000000000000000000000000000000000000002",
  contractAddress: null,
  cumulativeGasUsed: "0x5208",
  gasUsed: "0x5208",
  effectiveGasPrice: "0x3b9aca00",
  logs: [],
  logsBloom: "0x" + "00".repeat(256),
  status: "0x1",
  type: "0x0",
});

function handle(method, params) {
  switch (method) {
    case "eth_chainId": return "0x38";
    case "net_version": return "56";
    case "eth_blockNumber": return toHexQty(blockNumber);
    case "eth_gasPrice": return "0x3b9aca00"; // 1 gwei
    case "eth_maxPriorityFeePerGas": return "0x3b9aca00";
    case "eth_estimateGas": return "0x7a120"; // 500000
    case "eth_getBalance": return "0x21e19e0c9bab2400000"; // 10000 BNB
    case "eth_getTransactionCount": return "0x0";
    case "eth_call": {
      const [{ to, data }] = params;
      if (!data || data === "0x") return "0x";
      try {
        if ((to || "").toLowerCase() === "0x10ed43c718714eb63d5aa57b78b54704e256024e") {
          const dec = routerIface.decodeFunctionData("getAmountsOut", data);
          const amountIn = dec[0];
          return routerIface.encodeFunctionResult("getAmountsOut", [[amountIn, amountIn]]); // 1:1 模拟
        }
        const sel = data.slice(0, 10);
        const selMap = {
          "0x70a08231": () => tokenIface.encodeFunctionResult("balanceOf", [BigInt("10000000000000000000000")]), // 10000 代币
          "0xdd62ed3e": () => tokenIface.encodeFunctionResult("allowance", [0n]), // 默认未授权
          "0x313ce567": () => tokenIface.encodeFunctionResult("decimals", [18]),
          "0x95d89b41": () => tokenIface.encodeFunctionResult("symbol", ["TEST"]),
        };
        const fn = selMap[sel];
        if (fn) return fn();
      } catch { /* fallthrough */ }
      return "0x";
    }
    case "eth_sendRawTransaction": {
      const raw = params[0];
      const hash = keccak256(raw);
      txs.set(hash, raw);
      return hash;
    }
    case "eth_getTransactionReceipt": {
      const hash = params[0];
      return txs.has(hash) ? receiptFor(hash) : null;
    }
    case "eth_getTransactionByHash": {
      const hash = params[0];
      return txs.has(hash) ? { hash, blockHash: "0x" + "bb".repeat(32), blockNumber: toHexQty(blockNumber), transactionIndex: "0x0", from: "0x0000000000000000000000000000000000000001", to: "0x0000000000000000000000000000000000000002", value: "0x0", gas: "0x5208", gasPrice: "0x3b9aca00", input: "0x", nonce: "0x0", chainId: "0x38", v: "0x26", r: "0x" + "55".repeat(32), s: "0x" + "66".repeat(32), type: "0x0" } : null;
    }
    case "eth_getBlockByNumber": {
      const bn = blockNumber;
      return {
        number: toHexQty(bn), hash: "0x" + "bb".repeat(32),
        parentHash: "0x" + "aa".repeat(32), nonce: "0x0000000000000000000000000000000000000000",
        sha3Uncles: "0x" + "11".repeat(32), logsBloom: "0x" + "00".repeat(256),
        transactionsRoot: "0x" + "22".repeat(32), stateRoot: "0x" + "33".repeat(32),
        receiptsRoot: "0x" + "44".repeat(32), miner: "0x0000000000000000000000000000000000000000",
        difficulty: "0x0", totalDifficulty: "0x0", extraData: "0x",
        size: "0x220", gasLimit: "0x1c9c380", gasUsed: "0x5208",
        timestamp: toHexQty(Math.floor(Date.now() / 1000)),
        transactions: [...txs.keys()], uncles: [],
      };
    }
    default:
      return { __error: `method not supported: ${method}` };
  }
}

const server = http.createServer((req, res) => {
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    const payload = JSON.parse(body);
    const isBatch = Array.isArray(payload);
    const items = isBatch ? payload : [payload];
    const responses = items.map(({ id, method, params }) => {
      try {
        const r = handle(method, params || []);
        if (r && r.__error) return { jsonrpc: "2.0", id, error: { code: -32601, message: r.__error } };
        return { jsonrpc: "2.0", id, result: r };
      } catch (e) {
        return { jsonrpc: "2.0", id, error: { code: -32603, message: String(e) } };
      }
    });
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(isBatch ? responses : responses[0]));
  });
});

server.listen(8545, "127.0.0.1", () => console.log("mock rpc on http://127.0.0.1:8545"));
setInterval(() => { blockNumber++; }, 1500); // 模拟出块
