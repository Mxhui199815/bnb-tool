#!/usr/bin/env node
/**
 * BNB 批量转账脚本 (BSC 主网 / 测试网)
 *
 * 功能:
 *   - 读取 CSV / XLSX 转账名单 (to, amount, [remark], [wallet_index])
 *   - 支持助记词派生地址 (BIP44: m/44'/60'/0'/0/{index}) 或私钥列表
 *   - 逐笔发送, 自动管理 nonce, 自动重试并提高 gas 费
 *   - 发送前余额检查 / 地址校验 / 金额校验, 默认 dry-run
 *   - 输出结果 CSV (每笔 tx hash / 状态)
 *
 * 用法示例:
 *   node transfer.js --list sample-list.csv --dry-run
 *   node transfer.js --list sample-list.csv --mnemonic "..." --send --yes
 *   node transfer.js --list list.xlsx --private-keys "0x...,0x..." --send
 *
 * 安全提示:
 *   - 助记词/私钥只应通过环境变量或 secrets.json 传入, 不要写进命令行历史/脚本文件
 *   - 上线前务必先用 --dry-run 检查, 并小额试发
 */
import { ethers } from "ethers";
import ExcelJS from "exceljs";
import { readFile } from "node:fs/promises";
import readline from "node:readline/promises";
import { stdin as ioStdin, stdout as ioStdout } from "node:process";
import { pathToFileURL } from "node:url";

/* ============================ 配置 ============================ */

// BSC 主网公共 RPC 列表 (逗号分隔, 自动故障转移; 生产环境建议换成自建/可信节点)
const DEFAULT_RPC = "https://bsc-rpc.publicnode.com,https://bsc.meowrpc.com,https://bsc-dataseed.binance.org";
const DEFAULT_CHAIN_ID = 56;
const BIP44_PATH = "m/44'/60'/0'/0/"; // BSC / EVM 标准路径

const USAGE = `
用法:
  node transfer.js --list <名单文件> [选项]

必填:
  --list <path>             转账名单 CSV 或 XLSX
                            列: to(收款地址), amount(BNB 数量), [remark 备注],
                                [wallet_index 指定第几个发送钱包, 0 起]

钱包来源 (三选一, 也可用环境变量):
  --mnemonic "..."          助记词 (或用环境变量 MNEMONIC)
  --private-keys "0x..,0x.." 逗号分隔私钥列表 (或用环境变量 PRIVATE_KEYS)
  --secrets <json>          从 JSON 文件读取: {"mnemonic":"...","privateKeys":[...]}

网络:
  --rpc <url[,url,...]>     RPC 节点, 逗号分隔可故障转移 (默认 BSC 主网公共节点)
  --chain-id <n>            链 ID (默认 56; 测试网请用 97)
  --start-index <n>         助记词派生的起始序号 (默认 0)
  --senders <n>             使用几个发送钱包(轮询分配, 默认 1)

发送控制:
  --dry-run                 只检查并打印计划, 不广播 (默认)
  --send                    真正广播交易 (默认不广播)
  --yes                     跳过发送前的确认提示
  --gas-limit <n>           每笔 gas limit (默认 21000)
  --max-gas-price <gwei>    gas 费上限, 防止网络异常时费用失控 (默认 10)
  --fee-mode <legacy|eip1559>  费用模式 (默认 legacy, BSC 公共节点更稳定)
  --confirmations <n>       等待确认数 (默认 1; 0 表示广播后立即记录 hash)
  --max-retries <n>         单笔失败重试次数 (默认 3)
  --fee-bump-percent <n>    每次重试 gas 费上浮百分比 (默认 10)
  --retry-delay-ms <n>      重试间隔毫秒 (默认 3000)
  --wait-timeout-ms <n>     等待确认超时毫秒 (默认 60000)
  --output <path>           结果 CSV 路径 (默认 results-<时间戳>.csv)
  --skip-balance-check      跳过余额检查 (仅排错/测试用, 不推荐)
  -h, --help                显示帮助
`;

function parseArgs(argv) {
  const opts = { rpc: process.env.RPC_URL, chainId: process.env.CHAIN_ID, mnemonic: process.env.MNEMONIC, privateKeys: process.env.PRIVATE_KEYS };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => (i + 1 < argv.length ? argv[++i] : null);
    switch (a) {
      case "-h": case "--help": console.log(USAGE); process.exit(0);
      case "--list": opts.list = next(); break;
      case "--mnemonic": opts.mnemonic = next(); break;
      case "--private-keys": opts.privateKeys = next(); break;
      case "--secrets": opts.secrets = next(); break;
      case "--rpc": opts.rpc = next(); break;
      case "--chain-id": opts.chainId = next(); break;
      case "--start-index": opts.startIndex = Number(next()); break;
      case "--senders": opts.senders = Number(next()); break;
      case "--dry-run": opts.dryRun = true; break;
      case "--send": opts.dryRun = false; break;
      case "--yes": opts.yes = true; break;
      case "--gas-limit": opts.gasLimit = Number(next()); break;
      case "--max-gas-price": opts.maxGasPrice = Number(next()); break;
      case "--confirmations": opts.confirmations = Number(next()); break;
      case "--max-retries": opts.maxRetries = Number(next()); break;
      case "--fee-bump-percent": opts.feeBumpPercent = Number(next()); break;
      case "--retry-delay-ms": opts.retryDelayMs = Number(next()); break;
      case "--wait-timeout-ms": opts.waitTimeoutMs = Number(next()); break;
      case "--output": opts.output = next(); break;
      case "--skip-balance-check": opts.skipBalanceCheck = true; break;
      case "--fee-mode": opts.feeMode = next(); break;
      default:
        if (a.startsWith("-")) { console.error(`未知参数: ${a}\n${USAGE}`); process.exit(2); }
    }
  }
  return {
    ...opts,
    rpc: opts.rpc || DEFAULT_RPC,
    chainId: opts.chainId ? Number(opts.chainId) : DEFAULT_CHAIN_ID,
    dryRun: opts.dryRun !== false,   // 默认 dry-run
    send: opts.dryRun === false,
    yes: !!opts.yes,
    gasLimit: opts.gasLimit ?? 21000,
    maxGasPrice: opts.maxGasPrice ?? 10,
    confirmations: opts.confirmations ?? 1,
    maxRetries: opts.maxRetries ?? 3,
    feeBumpPercent: opts.feeBumpPercent ?? 10,
    retryDelayMs: opts.retryDelayMs ?? 3000,
    waitTimeoutMs: opts.waitTimeoutMs ?? 60000,
    startIndex: opts.startIndex ?? 0,
    senders: opts.senders ?? 1,
    skipBalanceCheck: !!opts.skipBalanceCheck,
    feeMode: opts.feeMode === "eip1559" ? "eip1559" : "legacy",
  };
}

/* ============================ 工具 ============================ */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const GRAY = (s) => `\x1b[90m${s}\x1b[0m`;
const GREEN = (s) => `\x1b[32m${s}\x1b[0m`;
const RED = (s) => `\x1b[31m${s}\x1b[0m`;
const YELLOW = (s) => `\x1b[33m${s}\x1b[0m`;
const CYAN = (s) => `\x1b[36m${s}\x1b[0m`;

function log(info, msg) { console.log(`${GRAY(`[${new Date().toISOString()}]`)} ${info} ${msg}`); }

/** 简易 CSV 解析器: 支持引号包裹、转义引号、CRLF/BOM */
function parseCsv(text) {
  text = text.replace(/^\uFEFF/, "");
  const rows = [];
  let row = [], field = "", inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else field += ch;
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ",") {
      row.push(field); field = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && text[i + 1] === "\n") i++;
      row.push(field); field = "";
      if (row.some((c) => c.trim() !== "")) rows.push(row);
      row = [];
    } else {
      field += ch;
    }
  }
  if (field !== "" || row.length) {
    row.push(field);
    if (row.some((c) => c.trim() !== "")) rows.push(row);
  }
  return rows;
}

/** 读取名单: 根据扩展名走 CSV 或 XLSX, 返回二维数组(字符串) */
async function readListFile(path) {
  const ext = path.toLowerCase().split(".").pop();
  if (ext === "xlsx" || ext === "xls") {
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.readFile(path);
    const ws = wb.worksheets[0];
    if (!ws) throw new Error(`XLSX 文件中没有工作表: ${path}`);
    const rows = [];
    ws.eachRow((row) => {
      const vals = (row.values || []).slice(1).map((v) => (v == null ? "" : String(v).trim()));
      if (vals.some((v) => v !== "")) rows.push(vals);
    });
    return rows;
  }
  const buf = await readFile(path);
  return parseCsv(buf.toString("utf8"));
}

const normalize = (s) => String(s ?? "").trim().toLowerCase().replace(/[\s_\-]+/g, "");

const ALIASES = {
  to: ["to", "address", "recipient", "receiver", "addr", "目标地址", "收款地址", "接收地址", "地址"],
  amount: ["amount", "value", "bnb", "数量", "金额", "转账金额", "转账数量"],
  remark: ["remark", "memo", "note", "备注", "留言"],
  walletIndex: ["walletindex", "senderindex", "fromindex", "sender", "wallet", "index", "钱包序号", "发送序号", "序号"],
};

function findHeaderCols(row) {
  const cols = {};
  for (let i = 0; i < row.length; i++) {
    const n = normalize(row[i]);
    for (const [key, aliases] of Object.entries(ALIASES)) {
      if (aliases.includes(n) && cols[key] === undefined) cols[key] = i;
    }
  }
  return cols;
}

/** 解析名单为结构化记录 */
function parseRows(rows) {
  if (!rows.length) throw new Error("名单为空");
  const header = findHeaderCols(rows[0]);
  const hasHeader = header.to !== undefined && header.amount !== undefined;
  const dataStart = hasHeader ? 1 : 0;
  const col = hasHeader
    ? header
    : { to: 0, amount: 1, remark: 2, walletIndex: -1 };

  const items = [];
  for (let r = dataStart; r < rows.length; r++) {
    const raw = rows[r];
    const get = (idx) => (idx >= 0 && idx < raw.length ? String(raw[idx]).trim() : "");
    const to = get(col.to);
    const amountStr = get(col.amount);
    const remark = col.remark !== undefined ? get(col.remark) : "";
    const wIdxStr = col.walletIndex !== undefined ? get(col.walletIndex) : "";

    if (!to && !amountStr) continue; // 空行
    if (!to) throw new Error(`第 ${r + 1} 行缺少收款地址`);
    if (!amountStr || isNaN(Number(amountStr.replace(/,/g, "")))) {
      throw new Error(`第 ${r + 1} 行金额无效: "${amountStr}"`);
    }
    const amount = Number(amountStr.replace(/,/g, "")); // 允许千分位
    if (!(amount > 0)) throw new Error(`第 ${r + 1} 行金额必须大于 0: "${amountStr}"`);
    const walletIndex = wIdxStr === "" ? -1 : Number(wIdxStr);
    if (wIdxStr !== "" && (!Number.isInteger(walletIndex) || walletIndex < 0)) {
      throw new Error(`第 ${r + 1} 行 wallet_index 无效: "${wIdxStr}"`);
    }
    items.push({ row: r + 1, to, amount, remark, walletIndex });
  }
  if (!items.length) throw new Error("名单中没有有效数据行");
  return { items, hasHeader };
}

/** 校验地址, 汇总重复收款人 */
function validateItems(items) {
  const seen = new Map();
  const dupes = [];
  for (const it of items) {
    if (!ethers.isAddress(it.to)) throw new Error(`第 ${it.row} 行地址无效: ${it.to}`);
    it.to = ethers.getAddress(it.to); // 统一 checksum 格式
    if (seen.has(it.to)) dupes.push(`${it.to} (第 ${seen.get(it.to)} 行和第 ${it.row} 行)`);
    seen.set(it.to, it.row);
  }
  if (dupes.length) console.log(`${YELLOW("[警告]")} 存在重复收款地址: ${dupes.join("; ")} (确认是否故意)`);
  return items;
}

/* ============================ 钱包 ============================ */

async function loadSecrets(opts) {
  if (opts.secrets) {
    const data = JSON.parse(await readFile(opts.secrets, "utf8"));
    return { mnemonic: data.mnemonic, privateKeys: data.privateKeys ?? data.private_keys ?? data.keys };
  }
  const mnemonic = opts.mnemonic;
  const privateKeys = opts.privateKeys
    ? String(opts.privateKeys).split(",").map((s) => s.trim()).filter(Boolean)
    : [];
  return { mnemonic, privateKeys };
}

function buildSenders(secrets, opts) {
  const count = Math.max(1, opts.senders);
  if (secrets.mnemonic && secrets.privateKeys?.length) {
    throw new Error("助记词和私钥不能同时提供, 请二选一");
  }
  let wallets = [];
  if (secrets.mnemonic) {
    ethers.Mnemonic.fromPhrase(secrets.mnemonic.trim()); // 校验助记词
    for (let i = 0; i < count; i++) {
      const idx = opts.startIndex + i;
      wallets.push(ethers.HDNodeWallet.fromPhrase(secrets.mnemonic.trim(), undefined, `${BIP44_PATH}${idx}`));
    }
  } else if (secrets.privateKeys?.length) {
    if (count > secrets.privateKeys.length) {
      throw new Error(`--senders=${count} 超过了私钥数量 ${secrets.privateKeys.length}`);
    }
    wallets = secrets.privateKeys.slice(0, count).map((k) => new ethers.Wallet(k.trim()));
  } else {
    throw new Error("未提供钱包来源: 请用 --mnemonic / --private-keys / --secrets, 或环境变量 MNEMONIC / PRIVATE_KEYS");
  }
  return wallets.map((w, i) => ({ index: opts.startIndex + i, wallet: w, address: w.address }));
}

/* ============================ 转账引擎 ============================ */

class TransferEngine {
  constructor(opts) {
    this.opts = opts;
    this.rpcList = String(opts.rpc || "").split(",").map((s) => s.trim()).filter(Boolean);
    if (!this.rpcList.length) this.rpcList = DEFAULT_RPC.split(",");
    this.providers = this.rpcList.map((url) => new ethers.JsonRpcProvider(url, opts.chainId, { staticNetwork: true }));
    this.rpcCursor = 0;
    this.nonces = new Map(); // key: `${rpcIdx}:${address}`
    this.hooks = opts.hooks || {}; // { onLog(text) } 供 APP 收集进度
  }

  pickProvider() {
    const idx = this.rpcCursor % this.providers.length;
    this.rpcCursor++;
    return { idx, provider: this.providers[idx] };
  }

  isRetriable(e) {
    return /timeout|rate\s*limit|too many|busy|unavailable|ETIMEDOUT|ECONNRESET|socket|server error|response would exceed|Unauthorized/i.test(
      e?.shortMessage || e?.message || String(e)
    );
  }

  /** 带多 RPC 故障转移的调用: fn 接收 provider, 失败自动换节点重试 */
  async call(fn, label) {
    let lastErr;
    for (let round = 0; round < 2; round++) {
      for (const provider of this.providers) {
        try {
          return await fn(provider);
        } catch (e) {
          lastErr = e;
          if (!this.isRetriable(e)) throw e;
          log(YELLOW("[重试]"), `${label} 失败: ${(e?.shortMessage || e?.message || String(e)).slice(0, 100)} (切换 RPC 节点)`);
        }
      }
    }
    throw lastErr;
  }

  async init() {
    const net = await this.call((p) => p.getNetwork(), "获取网络信息");
    log(CYAN("[网络]"), `${net.name} (chainId=${net.chainId}) @ ${this.rpcList.join(", ")}`);
    if (net.chainId !== BigInt(this.opts.chainId)) {
      throw new Error(`RPC 返回的 chainId (${net.chainId}) 与配置 (${this.opts.chainId}) 不一致`);
    }
  }

  /** 计算 gas 费用字段, attempt 为第几次重试 (0 起), 受 max-gas-price 上限保护 */
  async computeFeeFields(attempt = 0) {
    const { maxGasPrice, feeBumpPercent, feeMode } = this.opts;
    const cap = ethers.parseUnits(String(maxGasPrice), "gwei");
    const bumpBig = BigInt(Math.round((feeBumpPercent * attempt) / 100 * 100));
    const bump = (v) => v + (v * bumpBig) / 100n;

    // BSC 公共节点对 eth_feeHistory 支持差, 默认走 legacy gasPrice(单次调用, 稳定)
    const base = ethers.toBigInt(await this.call((p) => p.send("eth_gasPrice", []), "获取 gas 价"));
    if (feeMode === "eip1559") {
      let maxFee = bump(base * 2n);
      let prio = bump(ethers.toBigInt(await this.call((p) => p.send("eth_maxPriorityFeePerGas", []), "获取优先费")));
      if (maxFee > cap) maxFee = cap;
      if (prio > maxFee) prio = maxFee;
      if (prio === 0n) prio = 1n;
      return { maxFeePerGas: maxFee, maxPriorityFeePerGas: prio };
    }
    let gp = bump(base);
    if (gp > cap) gp = cap;
    return { gasPrice: gp };
  }

  async getFeePerTx() {
    const f = await this.computeFeeFields(0);
    return BigInt(this.opts.gasLimit) * (f.maxFeePerGas ?? f.gasPrice);
  }

  async nextNonce(provIdx, senderAddress, provider) {
    const key = `${provIdx}:${senderAddress}`;
    if (!this.nonces.has(key)) {
      this.nonces.set(key, await provider.getTransactionCount(senderAddress, "pending"));
    }
    const n = this.nonces.get(key);
    this.nonces.set(key, n + 1);
    return n;
  }

  async resetNonce(provIdx, senderAddress, provider) {
    this.nonces.set(`${provIdx}:${senderAddress}`, await provider.getTransactionCount(senderAddress, "pending"));
  }

  /** 发送前余额检查: 每个发送钱包的转出总额 + 手续费 <= 余额 */
  async checkBalances(items) {
    const assigned = new Map();
    for (const it of items) {
      const addr = it.sender.address; // run() 中已按 wallet_index / 轮询分配
      if (!assigned.has(addr)) assigned.set(addr, { count: 0, total: 0n });
      assigned.get(addr).count++;
      assigned.get(addr).total += ethers.parseEther(String(it.amount));
    }
    const feePerTx = await this.getFeePerTx();
    let ok = true;
    for (const [addr, a] of assigned) {
      const balance = await this.call((p) => p.getBalance(addr), `查询余额 (${addr.slice(0, 10)}...)`);
      const feeTotal = feePerTx * BigInt(a.count);
      const needed = a.total + feeTotal;
      console.log(`  ${CYAN(addr)}`);
      console.log(`    余额: ${ethers.formatEther(balance)} BNB   需转出: ${ethers.formatEther(a.total)} BNB + 手续费 ~${ethers.formatEther(feeTotal)} BNB`);
      if (balance < needed) {
        ok = false;
        console.log(`    ${RED("[余额不足]")} 需要 ${ethers.formatEther(needed)} BNB, 实际 ${ethers.formatEther(balance)} BNB`);
      } else {
        console.log(`    预计剩余: ${ethers.formatEther(balance - needed)} BNB`);
      }
    }
    return ok;
  }

  /** 单笔转账, 含重试 */
  async sendOne(sender, it, attempt, isDryRun) {
    const { gasLimit, confirmations, waitTimeoutMs } = this.opts;
    const { idx, provider } = this.pickProvider();
    const wallet = sender.wallet.connect(provider);
    const nonce = isDryRun ? 0 : await this.nextNonce(idx, sender.address, provider);
    const feeFields = await this.computeFeeFields(attempt);
    const value = ethers.parseEther(String(it.amount));

    if (isDryRun) {
      return { dryRun: true, nonce, feeFields, value };
    }

    try {
      const tx = await wallet.sendTransaction({
        to: it.to,
        value,
        nonce,
        gasLimit,
        ...feeFields,
      });
      let receipt = null;
      if (confirmations > 0) {
        try {
          receipt = await tx.wait(confirmations, waitTimeoutMs);
        } catch (e) {
          const err = new Error(`等待确认超时 (${waitTimeoutMs}ms), hash=${tx.hash}`);
          err.pendingHash = tx.hash;
          throw err;
        }
      }
      return { txHash: tx.hash, receipt, nonce, feeFields, value };
    } catch (e) {
      const msg = e?.shortMessage || e?.message || String(e);
      if (/nonce too low|NONCE_EXPIRED|already known/i.test(msg)) {
        log(YELLOW("[nonce]"), `${sender.address} nonce 冲突, 重新同步 nonce 后重试`);
        await this.resetNonce(idx, sender.address, provider);
      }
      throw e;
    }
  }

  /** 为每笔分配发送钱包 (wallet_index 指定或轮询) */
  assignSenders(senders, items) {
    let rr = 0;
    for (const it of items) {
      let sender;
      if (it.walletIndex >= 0) {
        sender = senders.find((s) => s.index === it.walletIndex);
        if (!sender) throw new Error(`第 ${it.row} 行 wallet_index=${it.walletIndex} 超出可用钱包范围 (${senders[0].index}~${senders[senders.length - 1].index})`);
      } else {
        sender = senders[rr % senders.length]; // 轮询
        rr++;
      }
      it.sender = sender;
    }
  }

  /** 逐笔发送主循环; onResult(result, done, total) 每笔完成后回调 (APP 进度用) */
  async runSends(items, onResult = null) {
    const opts = this.opts;
    const results = [];
    console.log(`\n${CYAN("========== 开始发送 ==========")}`);
    this.hooks.onLog?.(`========== 开始发送 ==========`);
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      let ok = false, errMsg = "", txHash = "", blockNumber = "";
      for (let attempt = 0; attempt <= opts.maxRetries && !ok; attempt++) {
        try {
          const r = await this.sendOne(it.sender, it, attempt, false);
          txHash = r.txHash;
          if (r.receipt) {
            blockNumber = String(r.receipt.blockNumber ?? "");
            ok = true;
            log(GREEN("[成功]"), `#${String(it.row).padStart(4)} ${it.sender.address} -> ${it.to}  ${it.amount} BNB  hash=${txHash}`);
            this.hooks.onLog?.(`[成功] 第${it.row}行 从 ${it.sender.address} -> ${it.to}  ${it.amount} BNB  hash=${txHash}`);
          } else {
            ok = true; // confirmations=0
            log(GREEN("[已广播]"), `#${String(it.row).padStart(4)} hash=${txHash} (未等待确认)`);
            this.hooks.onLog?.(`[已广播] 第${it.row}行 hash=${txHash} (未等待确认)`);
          }
        } catch (e) {
          errMsg = e?.shortMessage || e?.message || String(e);
          if (/nonce too low|NONCE_EXPIRED|already known/i.test(errMsg)) {
            attempt--; // nonce 冲突不算失败次数
            await sleep(opts.retryDelayMs);
            continue;
          }
          if (attempt < opts.maxRetries) {
            log(YELLOW("[重试]"), `#${String(it.row).padStart(4)} 失败: ${errMsg.slice(0, 200)} (重试 ${attempt + 1}/${opts.maxRetries}, gas 上浮 ${opts.feeBumpPercent}%)`);
            this.hooks.onLog?.(`[重试] 第${it.row}行 失败: ${errMsg.slice(0, 200)} (重试 ${attempt + 1}/${opts.maxRetries})`);
            await sleep(opts.retryDelayMs);
          }
        }
      }
      if (!ok) {
        log(RED("[失败]"), `#${String(it.row).padStart(4)} ${it.to}  ${it.amount} BNB  ${errMsg.slice(0, 300)}`);
        this.hooks.onLog?.(`[失败] 第${it.row}行 ${it.to}  ${it.amount} BNB  ${errMsg.slice(0, 300)}`);
      }
      const result = {
        row: it.row, from: it.sender.address, to: it.to, amount: it.amount,
        remark: it.remark, status: ok ? "ok" : "failed", txHash, blockNumber,
        error: ok ? "" : errMsg,
      };
      results.push(result);
      onResult?.(result, i + 1, items.length);
    }
    const okCount = results.filter((r) => r.status === "ok").length;
    console.log(`\n${CYAN("========== 完成 ==========")}`);
    console.log(`成功 ${okCount}/${results.length} 笔`);
    this.hooks.onLog?.(`========== 完成 ========== 成功 ${okCount}/${results.length} 笔`);
    return results;
  }

  async run(senders, items) {
    const opts = this.opts;
    this.assignSenders(senders, items);

    // 发送前展示计划
    console.log(`\n${CYAN("========== 转账计划 ==========")}`);
    const total = items.reduce((s, i) => s + i.amount, 0);
    console.log(`共 ${items.length} 笔, 合计 ${total} BNB, 使用 ${senders.length} 个发送钱包`);
    const preview = items.slice(0, 20);
    for (const it of preview) {
      const from = it.sender.address.slice(0, 10) + "..." + it.sender.address.slice(-6);
      const to = it.to.slice(0, 10) + "..." + it.to.slice(-6);
      console.log(`  #${String(it.row).padStart(4)}  ${GRAY(from)} -> ${to}  ${it.amount} BNB${it.walletIndex >= 0 ? ` (钱包#${it.walletIndex})` : ""}`);
    }
    if (items.length > preview.length) console.log(`  ... 共 ${items.length} 笔`);

    // 余额检查
    console.log(`\n${CYAN("---------- 余额检查 ----------")}`);
    const balanceOk = opts.skipBalanceCheck || await this.checkBalances(items);
    if (!balanceOk) {
      throw new Error("存在余额不足的发送钱包, 已中止。请充值或减少转账金额(仅查看计划可用 --skip-balance-check)。");
    }

    if (opts.dryRun) {
      console.log(`\n${GREEN("[dry-run]")} 以上为模拟检查, 未广播任何交易。确认无误后加 ${CYAN("--send")} 执行。`);
      return [];
    }

    // 确认提示
    if (!opts.yes) {
      if (!ioStdin.isTTY) {
        throw new Error("非交互式环境(无终端输入)请显式加 --yes 确认发送, 避免误操作。");
      }
      const rl = readline.createInterface({ input: ioStdin, output: ioStdout });
      const ans = await rl.question(`\n确认广播 ${items.length} 笔转账? 输入 yes 继续: `);
      rl.close();
      if (ans.trim().toLowerCase() !== "yes") {
        console.log("已取消, 未广播任何交易。");
        process.exit(0);
      }
    }

    return this.runSends(items);
  }
}

/* ============================ 结果输出 ============================ */

function csvEscape(v) {
  const s = String(v ?? "");
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

async function writeResults(results, outputPath) {
  const header = ["row", "from", "to", "amount", "remark", "status", "tx_hash", "block_number", "error"];
  const lines = [header.join(",")];
  for (const r of results) {
    lines.push([r.row, r.from, r.to, r.amount, r.remark, r.status, r.txHash, r.blockNumber, r.error]
      .map(csvEscape).join(","));
  }
  const { writeFile } = await import("node:fs/promises");
  await writeFile(outputPath, "\uFEFF" + lines.join("\n"), "utf8"); // 加 BOM, Excel 打开不乱码
  console.log(`结果已写入: ${outputPath}`);
}

/* ============================ 主流程 ============================ */

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (!opts.list) {
    console.error("缺少 --list 参数\n" + USAGE);
    process.exit(2);
  }

  const secrets = await loadSecrets(opts);
  const senders = buildSenders(secrets, opts);
  const rows = await readListFile(opts.list);
  const { items } = parseRows(rows);
  validateItems(items);

  console.log(`${CYAN("发送钱包:")}`);
  for (const s of senders) console.log(`  #${s.index}  ${s.address}`);

  const engine = new TransferEngine(opts);
  await engine.init();
  const results = await engine.run(senders, items);
  if (!opts.dryRun && results.length) {
    const out = opts.output || `results-${Date.now()}.csv`;
    await writeResults(results, out);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch((e) => {
    console.error(`\n${RED("[错误]")} ${e?.shortMessage || e?.message || e}`);
    process.exit(1);
  });
}

export {
  parseArgs, readListFile, parseRows, validateItems,
  loadSecrets, buildSenders, TransferEngine, writeResults, parseCsv,
};
