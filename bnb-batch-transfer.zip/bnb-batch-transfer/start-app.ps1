﻿$ErrorActionPreference = "Stop"
$port = 3000
if ($env:PORT) { $port = [int]$env:PORT }
$url = "http://127.0.0.1:$port"
Set-Location $PSScriptRoot

Write-Host ""
Write-Host "============================================"
Write-Host "  BNB 批量工具 (转账/钱包/归集/薄饼交易)"
Write-Host "============================================"
Write-Host ""

# 1) 服务已在运行 -> 直接打开浏览器
try {
  $r = Invoke-WebRequest -Uri $url -TimeoutSec 2 -UseBasicParsing
  if ($r.StatusCode -eq 200) {
    Write-Host "[提示] 服务已在运行, 正在打开浏览器..."
    Start-Process $url
    Start-Sleep 2
    exit 0
  }
} catch {}

# 2) 检查依赖
if (-not (Test-Path (Join-Path $PSScriptRoot "node_modules\ethers"))) {
  Write-Host "[错误] 缺少依赖 (node_modules)。"
  Write-Host "请先在此目录运行一次:  npm install"
  Write-Host "安装完成后再次双击 start-app.bat 即可。"
  Read-Host "按回车键关闭"
  exit 1
}

# 3) 找 node
$node = "node"
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  $candidate = "C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
  if (Test-Path $candidate) { $node = $candidate }
  else {
    Write-Host "[错误] 未找到 Node.js, 请先安装 https://nodejs.org 后再试。"
    Read-Host "按回车键关闭"
    exit 1
  }
}

# 4) 后台启动服务(最小化独立窗口, 关掉它即停止服务)
Write-Host "[启动] 正在启动服务, 请稍候..."
$arg = 'title BNB APP 服务 && "' + $node + '" app-server.js'
Start-Process cmd.exe -ArgumentList '/c', $arg -WorkingDirectory $PSScriptRoot -WindowStyle Minimized

# 5) 等待服务就绪
$ready = $false
for ($i = 0; $i -lt 12; $i++) {
  Start-Sleep -Milliseconds 500
  try {
    $r = Invoke-WebRequest -Uri $url -TimeoutSec 1 -UseBasicParsing
    if ($r.StatusCode -eq 200) { $ready = $true; break }
  } catch {}
}
if (-not $ready) {
  Write-Host "[错误] 服务启动失败。可能是端口 $port 被占用或运行报错。"
  Write-Host "提示: 先关闭其它 BNB 进程/窗口再重试。"
  Read-Host "按回车键关闭"
  exit 1
}

Write-Host "[成功] 服务已启动, 正在打开浏览器..."
Start-Process $url
Write-Host ""
Write-Host "提示: 服务在「BNB APP 服务」窗口中运行, 关闭该窗口即停止服务。"
Start-Sleep 3
exit 0
