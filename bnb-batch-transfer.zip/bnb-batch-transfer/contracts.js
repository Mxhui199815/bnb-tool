/**
 * PancakeSwap 合约配置与 ABI (BSC)
 * 需要交易的合约内容都在这里: Router 地址、WBNB、Router/代币 ABI
 */
export const WBNB = "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c"; // BSC WBNB
export const ROUTER_V2 = "0x10ED43C718714eb63d5aA57B78B54704E256024E"; // PancakeSwap V2 Router (主网)
export const ROUTER_V2_TESTNET = "0xD99D1c33F9fC3444f8101754aBC46c52416550D1"; // 测试网

/** PancakeSwap V2 Router ABI (交易用到的函数) */
export const ROUTER_ABI = [
  "function getAmountsOut(uint amountIn, address[] path) external view returns (uint[] memory amounts)",
  "function getAmountsIn(uint amountOut, address[] path) external view returns (uint[] memory amounts)",
  "function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] path, address to, uint deadline) external returns (uint[] memory amounts)",
  "function swapExactETHForTokens(uint amountOutMin, address[] path, address to, uint deadline) external payable returns (uint[] memory amounts)",
  "function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] path, address to, uint deadline) external returns (uint[] memory amounts)",
  "function swapExactTokensForTokensSupportingFeeOnTransferTokens(uint amountIn, uint amountOutMin, address[] path, address to, uint deadline) external",
  "function swapExactETHForTokensSupportingFeeOnTransferTokens(uint amountOutMin, address[] path, address to, uint deadline) external payable",
  "function swapExactTokensForETHSupportingFeeOnTransferTokens(uint amountIn, uint amountOutMin, address[] path, address to, uint deadline) external",
];

/** 标准 ERC20 / BEP20 代币 ABI */
export const TOKEN_ABI = [
  "function balanceOf(address owner) view returns (uint256)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
];
