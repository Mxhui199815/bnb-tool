#!/usr/bin/env node
/**
 * BNB 批量转账 - 本地网页版 APP 服务端
 *
 * 启动:  node app-server.js [--port 3000] [--host 127.0.0.1]
 * 打开:  http://127.0.0.1:3000
 *
 * 说明: 密钥只在内存中使用, 不落盘、不记录日志; 服务默认只监听本机。
 * 所有转账逻辑复用 transfer.js(CLI 与 APP 同源)。
 */
import { createServer } from "node:http";
import { readFile, writeFile, mkdtemp, rm, mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, extname, basename } from "node:path";
import { randomUUID } from "node:crypto";
import { fileURLToPath } from "node:url";
import { dirname } from "node:path";
import { ethers } from "ethers";
import { parseRows, validateItems, buildSenders, TransferEngine, readListFile, parseCsv } from "./transfer.js";
import { WBNB, ROUTER_V2, ROUTER_V2_TESTNET, ROUTER_ABI, TOKEN_ABI } from "./contracts.js";
import { verifyLicenseKey, tierLabel, remainingMs } from "./license.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "127.0.0.1";

const jobs = new Map();       // jobId -> job
let activeSendJob = null;     // 同时只允许一个发送任务

/* ============================ 工具 ============================ */

function json(res, status, data) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch (e) { reject(new Error("请求体不是合法 JSON")); }
    });
    req.on("error", reject);
  });
}

/** 把配置转成 TransferEngine 需要的 opts */
function makeOpts(cfg, hooks) {
  return {
    rpc: cfg.rpc || undefined,
    chainId: cfg.chainId ? Number(cfg.chainId) : 56,
    startIndex: cfg.startIndex ?? 0,
    senders: cfg.senders ?? 1,
    gasLimit: cfg.gasLimit ?? 21000,
    maxGasPrice: cfg.maxGasPrice ?? 10,
    confirmations: cfg.confirmations ?? 1,
    maxRetries: cfg.maxRetries ?? 3,
    feeBumpPercent: cfg.feeBumpPercent ?? 10,
    retryDelayMs: cfg.retryDelayMs ?? 3000,
    waitTimeoutMs: cfg.waitTimeoutMs ?? 60000,
    skipBalanceCheck: !!cfg.skipBalanceCheck,
    feeMode: cfg.feeMode === "eip1559" ? "eip1559" : "legacy",
    hooks,
  };
}

function getSecrets(cfg) {
  if (cfg.secretsJson) {
    return { mnemonic: cfg.secretsJson.mnemonic, privateKeys: cfg.secretsJson.privateKeys ?? cfg.secretsJson.private_keys ?? cfg.secretsJson.keys };
  }
  const privateKeys = Array.isArray(cfg.privateKeys)
    ? cfg.privateKeys
    : (cfg.privateKeys ? String(cfg.privateKeys).split(",").map((s) => s.trim()).filter(Boolean) : []);
  return { mnemonic: cfg.mnemonic || undefined, privateKeys };
}

async function makeEngine(cfg, hooks) {
  const opts = makeOpts(cfg, hooks);
  const secrets = getSecrets(cfg);
  const senders = buildSenders(secrets, opts);
  const engine = new TransferEngine(opts);
  return { engine, senders, opts };
}

/** 解析上传的名单文件(base64 二进制 或 纯文本 CSV) */
async function handleParse(cfg) {
  const dir = await mkdtemp(join(tmpdir(), "bnb-transfer-"));
  let filePath;
  try {
    const name = cfg.filename || "upload.csv";
    const ext = (extname(name) || ".csv").toLowerCase();
    if (cfg.text != null) {
      filePath = join(dir, "paste" + (ext === ".xlsx" || ext === ".xls" ? ".csv" : ext));
      await writeFile(filePath, String(cfg.text).replace(/^\uFEFF/, ""), "utf8");
    } else if (cfg.dataBase64) {
      filePath = join(dir, basename(name).replace(/[^\w.\-]/g, "_") || "upload" + ext);
      await writeFile(filePath, Buffer.from(cfg.dataBase64, "base64"));
    } else {
      throw new Error("缺少文件内容: 请提供 dataBase64 或 text");
    }
    const rows = await readListFile(filePath);
    const { items } = parseRows(rows);
    validateItems(items);
    return { items };
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

/* ============================ 钱包工具 API (批量创建/管理) ============================ */

const BIP44 = "m/44'/60'/0'/0/";
const DATA_DIR = join(__dirname, "data");
const WALLETS_FILE = join(DATA_DIR, "wallets.json");

function deriveWallets(mnemonic, startIndex, count) {
  const out = [];
  for (let i = 0; i < count; i++) {
    const idx = startIndex + i;
    const w = ethers.HDNodeWallet.fromPhrase(mnemonic.trim(), undefined, `${BIP44}${idx}`);
    out.push({ index: idx, address: w.address, privateKey: w.privateKey });
  }
  return out;
}

async function readWalletsFile() {
  try { return JSON.parse(await readFile(WALLETS_FILE, "utf8")); }
  catch { return []; }
}

async function writeWalletsFile(list) {
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(WALLETS_FILE, JSON.stringify(list, null, 2), "utf8");
}

/** 批量创建冷钱包: new_mnemonic 新助记词派生 / existing_mnemonic 已有助记词派生 / random_keys 独立私钥 */
async function apiWalletsGenerate(res, body) {
  const mode = body.mode || "new_mnemonic";
  const count = Math.min(1000, Math.max(1, Number(body.count) || 1));
  const startIndex = Math.max(0, Number(body.startIndex) || 0);
  let mnemonic = null, wallets;
  if (mode === "new_mnemonic") {
    // 支持传入已有助记词续派生(APP 追加生成用); 未传则新建
    mnemonic = (body.mnemonic || "").trim() || ethers.Wallet.createRandom().mnemonic.phrase;
    if (body.mnemonic) ethers.Mnemonic.fromPhrase(mnemonic);
    wallets = deriveWallets(mnemonic, startIndex, count);
  } else if (mode === "existing_mnemonic") {
    if (!body.mnemonic) throw new Error("请提供助记词");
    ethers.Mnemonic.fromPhrase(body.mnemonic.trim()); // 校验
    wallets = deriveWallets(body.mnemonic, startIndex, count);
  } else if (mode === "random_keys") {
    wallets = [];
    for (let i = 0; i < count; i++) {
      const w = ethers.Wallet.createRandom();
      wallets.push({ index: startIndex + i, address: w.address, privateKey: w.privateKey });
    }
  } else {
    throw new Error("未知模式: " + mode);
  }
  json(res, 200, { ok: true, mode, mnemonic, wallets });
}

/** 批量导入钱包(用于管理列表): mnemonic / privateKeys / csv */
async function apiWalletsImport(res, body) {
  const mode = body.mode;
  let wallets = [];
  if (mode === "mnemonic") {
    const count = Math.min(1000, Math.max(1, Number(body.count) || 1));
    const startIndex = Math.max(0, Number(body.startIndex) || 0);
    if (!body.mnemonic) throw new Error("请提供助记词");
    ethers.Mnemonic.fromPhrase(body.mnemonic.trim());
    wallets = deriveWallets(body.mnemonic, startIndex, count);
  } else if (mode === "privateKeys") {
    const keys = Array.isArray(body.privateKeys)
      ? body.privateKeys
      : String(body.privateKeys || "").split(",").map((s) => s.trim()).filter(Boolean);
    if (!keys.length) throw new Error("请提供私钥");
    wallets = keys.map((k, i) => {
      const w = new ethers.Wallet(k.trim());
      return { index: i, address: w.address, privateKey: w.privateKey };
    });
  } else if (mode === "csv") {
    if (!body.text) throw new Error("请粘贴 CSV 内容");
    const rows = parseCsv(String(body.text));
    if (!rows.length) throw new Error("CSV 为空");
    // 表头识别: 首行若第一列不是地址则视为表头
    let start = 0;
    if (!ethers.isAddress(rows[0][0]?.trim() || "")) start = 1;
    for (let i = start; i < rows.length; i++) {
      const r = rows[i];
      const address = (r[0] || "").trim();
      const privateKey = (r[1] || "").trim();
      const label = (r[2] || "").trim();
      if (!address) continue;
      if (!ethers.isAddress(address)) throw new Error(`CSV 第 ${i + 1} 行地址无效: ${address}`);
      let pk = null;
      if (privateKey) {
        const w = new ethers.Wallet(privateKey); // 校验, 地址不匹配时警告
        pk = w.privateKey;
      }
      wallets.push({ index: i, address: ethers.getAddress(address), privateKey: pk, label });
    }
    if (!wallets.length) throw new Error("CSV 中没有有效行");
  } else {
    throw new Error("未知导入方式: " + mode);
  }
  json(res, 200, { ok: true, wallets });
}

/** 批量查询余额 */
async function apiWalletsBalances(res, body) {
  const addresses = (body.addresses || []).filter(Boolean);
  if (!addresses.length) throw new Error("没有地址可查询");
  const opts = { rpc: body.rpc || undefined, chainId: body.chainId ? Number(body.chainId) : 56, maxGasPrice: 10, feeMode: "legacy" };
  const engine = new TransferEngine(opts); // 复用多 RPC 故障转移
  const out = [];
  for (const addr of addresses) {
    const balance = await engine.call((p) => p.getBalance(addr), `查询余额 (${addr.slice(0, 10)}...)`);
    out.push({ address: addr, balance: ethers.formatEther(balance) });
  }
  json(res, 200, { ok: true, balances: out });
}

async function apiWalletsList(res) {
  json(res, 200, { ok: true, wallets: await readWalletsFile() });
}

async function apiWalletsSave(res, body) {
  const list = (body.wallets || [])
    .map((w) => ({ address: w.address, label: String(w.label ?? ""), hasKey: !!w.hasKey }))
    .filter((w) => ethers.isAddress(w.address));
  await writeWalletsFile(list);
  json(res, 200, { ok: true, count: list.length });
}

/* ============================ 批量归集 API ============================ */

function buildSourceWallets(body) {
  const source = body.source || "mnemonic";
  if (source === "mnemonic") {
    const mnemonic = (body.mnemonic || "").trim();
    if (!mnemonic) throw new Error("请提供助记词");
    ethers.Mnemonic.fromPhrase(mnemonic);
    const count = Math.min(1000, Math.max(1, Number(body.count) || 1));
    const startIndex = Math.max(0, Number(body.startIndex) || 0);
    return deriveWallets(mnemonic, startIndex, count);
  }
  if (source === "privateKeys") {
    const keys = Array.isArray(body.privateKeys)
      ? body.privateKeys
      : String(body.privateKeys || "").split(",").map((s) => s.trim()).filter(Boolean);
    if (!keys.length) throw new Error("请提供私钥");
    return keys.map((k, i) => {
      const w = new ethers.Wallet(k.trim());
      return { index: i, address: w.address, privateKey: w.privateKey };
    });
  }
  if (source === "managed") {
    const addresses = body.addresses || [];
    const keys = body.keys || [];
    if (!addresses.length) throw new Error("管理列表为空");
    return addresses.map((a, i) => ({ index: i, address: String(a).trim(), privateKey: keys[i] || null }));
  }
  throw new Error("未知来源: " + source);
}

/** 归集检查: 列出每个源钱包余额 / 手续费 / 可归集金额 */
async function apiConsolidatePreview(res, body) {
  const target = ethers.getAddress(String(body.target || "").trim());
  const sources = buildSourceWallets(body);
  if (!sources.length) throw new Error("没有源钱包");

  const opts = {
    rpc: body.rpc || undefined, chainId: body.chainId ? Number(body.chainId) : 56,
    gasLimit: body.gasLimit ?? 21000, maxGasPrice: body.maxGasPrice ?? 10, feeMode: "legacy",
    feeBumpPercent: body.feeBumpPercent ?? 10, maxRetries: body.maxRetries ?? 3,
    retryDelayMs: body.retryDelayMs ?? 3000, waitTimeoutMs: body.waitTimeoutMs ?? 60000,
    confirmations: body.confirmations ?? 1,
  };
  const engine = new TransferEngine(opts);
  const feePerTx = await engine.getFeePerTx();
  const reserve = (feePerTx * 110n) / 100n; // 预留 10% 缓冲, 防止 gas 上涨

  const plan = [];
  for (const s of sources) {
    const balance = BigInt(await engine.call((p) => p.getBalance(s.address), `查询余额 (${s.address.slice(0, 10)}...)`));
    let amount = 0n, ok = false, reason = "";
    if (balance <= reserve) reason = "余额不足以支付手续费";
    else if (s.address.toLowerCase() === target.toLowerCase()) reason = "源地址=目标地址, 跳过";
    else if (!s.privateKey) reason = "无私钥, 仅查询余额";
    else { amount = balance - reserve; ok = true; }
    plan.push({
      index: s.index, address: s.address, hasKey: !!s.privateKey,
      balance: ethers.formatEther(balance), fee: ethers.formatEther(feePerTx),
      amount: ethers.formatEther(amount), ok, reason,
    });
  }
  const okCount = plan.filter((p) => p.ok).length;
  const total = plan.filter((p) => p.ok).reduce((s, p) => s + Number(p.amount), 0);
  json(res, 200, {
    ok: true, target, plan, okCount,
    total: Math.round(total * 1e8) / 1e8,
    feePerTx: ethers.formatEther(feePerTx),
  });
}

/** 执行归集(后台任务, 轮询 /api/job/:id) */
async function apiConsolidateSend(res, body) {
  if (activeSendJob) { json(res, 409, { ok: false, error: "已有任务在进行中, 请等待完成" }); return; }
  const target = ethers.getAddress(String(body.target || "").trim());
  const sources = buildSourceWallets(body);
  if (!sources.length) throw new Error("没有源钱包");

  const jobId = randomUUID();
  const job = { id: jobId, status: "running", logs: [], results: [], done: 0, total: sources.length, startedAt: Date.now(), finishedAt: null, error: "" };
  jobs.set(jobId, job);
  activeSendJob = jobId;

  const run = (async () => {
    const hooks = { onLog: (text) => job.logs.push(`[${new Date().toLocaleTimeString()}] ${text}`) };
    const opts = {
      rpc: body.rpc || undefined, chainId: body.chainId ? Number(body.chainId) : 56,
      gasLimit: body.gasLimit ?? 21000, maxGasPrice: body.maxGasPrice ?? 10, feeMode: "legacy",
      confirmations: body.confirmations ?? 1, maxRetries: body.maxRetries ?? 3,
      feeBumpPercent: body.feeBumpPercent ?? 10, retryDelayMs: body.retryDelayMs ?? 3000,
      waitTimeoutMs: body.waitTimeoutMs ?? 60000, hooks,
    };
    const engine = new TransferEngine(opts);
    await engine.init();

    const senders = sources.filter((s) => s.privateKey).map((s) => ({ index: s.index, wallet: new ethers.Wallet(s.privateKey), address: s.address }));
    if (!senders.length) throw new Error("没有可发送的源钱包(缺失私钥)");

    const feePerTx = await engine.getFeePerTx();
    const reserve = (feePerTx * 110n) / 100n;
    const items = [];
    for (const s of sources) {
      if (!s.privateKey || s.address.toLowerCase() === target.toLowerCase()) continue;
      const balance = BigInt(await engine.call((p) => p.getBalance(s.address), `查询余额 (${s.address.slice(0, 10)}...)`));
      if (balance <= reserve) continue;
      const amount = balance - reserve;
      items.push({ row: s.index + 1, to: target, amount: Number(ethers.formatEther(amount)), remark: "归集", walletIndex: s.index });
    }
    if (!items.length) throw new Error("没有可归集的钱包(余额不足或均已跳过)");

    engine.assignSenders(senders, items);
    const results = await engine.runSends(items, (result, done, total) => {
      job.results.push(result);
      job.done = done;
      job.total = total;
    });
    job.status = "done";
    job.finishedAt = Date.now();
    job.results = results;
  })().catch((e) => {
    job.status = "failed";
    job.error = e?.shortMessage || e?.message || String(e);
    job.finishedAt = Date.now();
  }).finally(() => {
    if (activeSendJob === jobId) activeSendJob = null;
  });

  json(res, 200, { ok: true, jobId });
}

/* ============================ 薄饼交易 (PancakeSwap 批量买卖) ============================ */

const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
const MAX_UINT = ethers.MaxUint256;

function parseSwapItems(body) {
  return (body.items || []).map((it, i) => ({
    row: it.row ?? i + 1,
    token: String(it.token || "").trim(),
    amount: Number(it.amount),
    direction: it.direction === "sell" ? "sell" : "buy",
    slippage: it.slippage == null || it.slippage === "" ? null : Number(it.slippage),
    remark: it.remark ?? "",
    walletIndex: it.walletIndex ?? -1,
  }));
}

function getRouterAddress(body) {
  const custom = (body.router || "").trim();
  if (custom) {
    if (!ethers.isAddress(custom)) throw new Error("Router 合约地址无效: " + custom);
    return ethers.getAddress(custom);
  }
  const chainId = body.chainId ? Number(body.chainId) : 56;
  return chainId === 97 ? ROUTER_V2_TESTNET : ROUTER_V2;
}

/** 读取代币信息(decimals/symbol), 失败用默认值 */
async function getTokenInfo(engine, tokenAddr) {
  const iface = new ethers.Interface(TOKEN_ABI);
  const call = async (method, args) => {
    const data = iface.encodeFunctionData(method, args);
    const ret = await engine.call((p) => p.call({ to: tokenAddr, data }), `${method}(${tokenAddr.slice(0, 8)}...)`);
    return iface.decodeFunctionResult(method, ret)[0];
  };
  let decimals = 18, symbol = "TOKEN";
  try { decimals = Number(await call("decimals", [])); } catch { /* 非标准 */ }
  try { symbol = String(await call("symbol", [])).slice(0, 12); } catch { /* 非标准 */ }
  return { decimals, symbol };
}

/** 广播一笔合约交易(自动 nonce / gas 上限 / 重试), 返回 { txHash, receipt } */
async function broadcastTx(engine, sender, txReq, label) {
  const { idx, provider } = engine.pickProvider();
  const wallet = sender.wallet.connect(provider);
  const nonce = await engine.nextNonce(idx, sender.address, provider);
  let lastErr;
  for (let attempt = 0; attempt <= engine.opts.maxRetries; attempt++) {
    try {
      const feeFields = await engine.computeFeeFields(attempt);
      const tx = await wallet.sendTransaction({ ...txReq, nonce, ...feeFields });
      let receipt = null;
      if (engine.opts.confirmations > 0) {
        try { receipt = await tx.wait(engine.opts.confirmations, engine.opts.waitTimeoutMs); }
        catch (e) { const err = new Error(`等待确认超时, hash=${tx.hash}`); err.pendingHash = tx.hash; throw err; }
      }
      return { txHash: tx.hash, receipt };
    } catch (e) {
      lastErr = e;
      const msg = e?.shortMessage || e?.message || String(e);
      if (/nonce too low|NONCE_EXPIRED|already known/i.test(msg)) {
        await engine.resetNonce(idx, sender.address, provider);
        attempt--;
        await sleepMs(engine.opts.retryDelayMs);
        continue;
      }
      if (attempt < engine.opts.maxRetries) {
        engine.hooks.onLog?.(`[重试] ${label} 失败: ${msg.slice(0, 150)}`);
        await sleepMs(engine.opts.retryDelayMs);
      }
    }
  }
  throw lastErr;
}

/** 薄饼交易检查: 每行校验余额/授权, 预估输出与滑点后的最少输出 */
async function apiSwapPreview(res, body) {
  const items = parseSwapItems(body);
  if (!items.length) throw new Error("交易名单为空");
  const router = getRouterAddress(body);
  const { engine, senders } = await makeEngine(body, {});
  if (!senders.length) throw new Error("未提供发送钱包");
  engine.assignSenders(senders, items);

  const routerIface = new ethers.Interface(ROUTER_ABI);
  const tokenIface = new ethers.Interface(TOKEN_ABI);
  const defaultSlippage = body.slippage == null || body.slippage === "" ? 1 : Number(body.slippage);
  const fee0 = await engine.computeFeeFields(0);
  const feePerGas = fee0.maxFeePerGas ?? fee0.gasPrice;
  const gasEstimate = 300000n; // 保守估算每笔 swap 的 gas
  const plan = [];

  for (const it of items) {
    if (!ethers.isAddress(it.token)) throw new Error(`第 ${it.row} 行代币地址无效: ${it.token}`);
    const token = ethers.getAddress(it.token);
    const slippage = it.slippage == null ? defaultSlippage : it.slippage;
    if (!(slippage >= 0 && slippage <= 50)) throw new Error(`第 ${it.row} 行滑点无效: ${slippage}%`);
    const info = await getTokenInfo(engine, token);
    const senderAddr = it.sender.address;
    const path = it.direction === "buy" ? [WBNB, token] : [token, WBNB];
    const amountIn = ethers.parseUnits(String(it.amount), it.direction === "buy" ? 18 : info.decimals);

    let balance = null, allowance = null, reason = "", ok = true;
    if (it.direction === "buy") {
      balance = await engine.call((p) => p.getBalance(senderAddr), `查询 BNB 余额 (${senderAddr.slice(0, 10)}...)`);
      const need = amountIn + gasEstimate * feePerGas;
      if (balance < need) { ok = false; reason = `BNB 余额不足: 需 ${ethers.formatEther(need)}`; }
    } else {
      const balData = tokenIface.encodeFunctionData("balanceOf", [senderAddr]);
      balance = (await engine.call((p) => p.call({ to: token, data: balData }), `查询代币余额 (${token.slice(0, 8)}...)`));
      balance = tokenIface.decodeFunctionResult("balanceOf", balance)[0];
      if (balance < amountIn) { ok = false; reason = `代币余额不足: 需 ${ethers.formatUnits(amountIn, info.decimals)} ${info.symbol}`; }
      else {
        const alData = tokenIface.encodeFunctionData("allowance", [senderAddr, router]);
        allowance = tokenIface.decodeFunctionResult("allowance", (await engine.call((p) => p.call({ to: token, data: alData }), `查询授权 (${token.slice(0, 8)}...)`)))[0];
        if (allowance < amountIn) reason = `需先授权 Router (allowance 不足)`;
      }
    }

    // 输出预估
    let out0 = null, outMin = null, estimateError = "";
    try {
      const data = routerIface.encodeFunctionData("getAmountsOut", [amountIn, path]);
      const ret = await engine.call((p) => p.call({ to: router, data }), "getAmountsOut");
      const amounts = routerIface.decodeFunctionResult("getAmountsOut", ret)[0];
      out0 = amounts[amounts.length - 1];
      outMin = out0 - (out0 * BigInt(Math.round(slippage * 100)) / 10000n);
    } catch (e) { estimateError = e?.shortMessage || e?.message || String(e); }

    plan.push({
      row: it.row, token, symbol: info.symbol, decimals: info.decimals,
      direction: it.direction, slippage,
      amountIn: ethers.formatUnits(amountIn, it.direction === "buy" ? 18 : info.decimals),
      balance: ethers.formatEther(balance),
      allowance: allowance == null ? null : ethers.formatUnits(allowance, info.decimals),
      out0: out0 == null ? null : ethers.formatUnits(out0, info.decimals),
      outMin: outMin == null ? null : ethers.formatUnits(outMin, info.decimals),
      ok, reason, estimateError,
    });
  }
  const okCount = plan.filter((p) => p.ok).length;
  json(res, 200, { ok: true, router, plan, okCount });
}

/** 执行薄饼批量交易(后台任务, 轮询 /api/job/:id) */
async function apiSwapSend(res, body) {
  if (activeSendJob) { json(res, 409, { ok: false, error: "已有任务在进行中, 请等待完成" }); return; }
  const items = parseSwapItems(body);
  if (!items.length) throw new Error("交易名单为空");
  const router = getRouterAddress(body);
  const recipient = (body.recipient || "").trim();

  const jobId = randomUUID();
  const job = { id: jobId, status: "running", logs: [], results: [], done: 0, total: items.length, startedAt: Date.now(), finishedAt: null, error: "" };
  jobs.set(jobId, job);
  activeSendJob = jobId;

  const run = (async () => {
    const hooks = { onLog: (text) => job.logs.push(`[${new Date().toLocaleTimeString()}] ${text}`) };
    const { engine, senders } = await makeEngine({ ...body, hooks }, hooks);
    if (!senders.length) throw new Error("未提供发送钱包");
    await engine.init();
    engine.assignSenders(senders, items);

    const routerIface = new ethers.Interface(ROUTER_ABI);
    const tokenIface = new ethers.Interface(TOKEN_ABI);
    const defaultSlippage = body.slippage == null || body.slippage === "" ? 1 : Number(body.slippage);
    const deadline = BigInt(Math.floor(Date.now() / 1000) + 600);

    for (const it of items) {
      const sender = it.sender;
      const toAddr = recipient && ethers.isAddress(recipient) ? ethers.getAddress(recipient) : sender.address;
      const slippage = it.slippage == null ? defaultSlippage : it.slippage;
      const info = await getTokenInfo(engine, ethers.getAddress(it.token));
      const path = it.direction === "buy" ? [WBNB, it.token] : [it.token, WBNB];
      const amountIn = ethers.parseUnits(String(it.amount), it.direction === "buy" ? 18 : info.decimals);
      const out = it.direction === "buy" ? info.decimals : 18; // 输出小数位

      let ok = false, errMsg = "", approveHash = "", swapHash = "", blockNumber = "";
      try {
        // 卖出: 先确保授权
        if (it.direction === "sell") {
          const alData = tokenIface.encodeFunctionData("allowance", [sender.address, router]);
          const allowance = tokenIface.decodeFunctionResult("allowance", (await engine.call((p) => p.call({ to: it.token, data: alData }), "查询授权")))[0];
          if (allowance < amountIn) {
            const appData = tokenIface.encodeFunctionData("approve", [router, MAX_UINT]);
            const r = await broadcastTx(engine, sender, { to: it.token, data: appData, gasLimit: 60000n }, `授权 ${it.token.slice(0, 8)}`);
            approveHash = r.txHash;
            engine.hooks.onLog?.(`[已授权] 第${it.row}行 approve=${approveHash}`);
          }
        }
        // 构造 swap 交易
        const slippageBp = BigInt(Math.round(slippage * 100));
        const out0 = await (async () => {
          const data = routerIface.encodeFunctionData("getAmountsOut", [amountIn, path]);
          const ret = await engine.call((p) => p.call({ to: router, data }), "getAmountsOut");
          return routerIface.decodeFunctionResult("getAmountsOut", ret)[0].slice(-1)[0];
        })();
        const outMin = out0 - (out0 * slippageBp / 10000n);
        let txReq;
        if (it.direction === "buy") {
          txReq = { to: router, value: amountIn, data: routerIface.encodeFunctionData("swapExactETHForTokens", [outMin, path, toAddr, deadline]) };
        } else {
          txReq = { to: router, data: routerIface.encodeFunctionData("swapExactTokensForETH", [amountIn, outMin, path, toAddr, deadline]) };
        }
        // gas 预估(失败用保守上限)
        let gasLimit = 500000n;
        try { gasLimit = await engine.call((p) => p.estimateGas({ ...txReq, from: sender.address }), "预估 gas"); } catch { /* 用保守值 */ }
        txReq.gasLimit = gasLimit;

        const r = await broadcastTx(engine, sender, txReq, `swap 第${it.row}行`);
        swapHash = r.txHash;
        blockNumber = r.receipt ? String(r.receipt.blockNumber ?? "") : "";
        ok = true;
        engine.hooks.onLog?.(`[成功] 第${it.row}行 ${it.direction === "buy" ? "买" : "卖"} ${it.amount} -> swap=${swapHash}`);
      } catch (e) {
        errMsg = e?.shortMessage || e?.message || String(e);
        engine.hooks.onLog?.(`[失败] 第${it.row}行 ${errMsg.slice(0, 200)}`);
      }
      job.results.push({ row: it.row, from: sender.address, to: it.token, token: it.token, symbol: info.symbol, direction: it.direction, amount: it.amount, status: ok ? "ok" : "failed", approveHash, txHash: swapHash, blockNumber, error: ok ? "" : errMsg });
      job.done++;
      job.total = items.length;
    }
    job.status = "done";
    job.finishedAt = Date.now();
  })().catch((e) => {
    job.status = "failed";
    job.error = e?.shortMessage || e?.message || String(e);
    job.finishedAt = Date.now();
  }).finally(() => {
    if (activeSendJob === jobId) activeSendJob = null;
  });

  json(res, 200, { ok: true, jobId });
}

/* ============================ 会员密钥 ============================ */

const LICENSE_FILE = join(DATA_DIR, "license.json");

async function readLicense() {
  try { return JSON.parse(await readFile(LICENSE_FILE, "utf8")); }
  catch { return null; }
}
async function writeLicense(rec) {
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(LICENSE_FILE, JSON.stringify(rec, null, 2), "utf8");
}

function licenseStatus(rec) {
  if (!rec || !rec.key) return { activated: false, valid: false };
  const v = verifyLicenseKey(rec.key);
  if (!v.valid) return { activated: true, valid: false, reason: v.reason, key: rec.key };
  const remain = remainingMs(v.payload);
  return {
    activated: true, valid: true,
    key: rec.key, id: v.payload.id,
    tier: v.payload.tier, tierLabel: tierLabel(v.payload.tier),
    issuedAt: v.payload.iat, expiresAt: v.payload.exp, remainingMs: remain,
  };
}

async function apiLicenseStatus(res) {
  json(res, 200, { ok: true, ...licenseStatus(await readLicense()) });
}

async function apiLicenseActivate(res, body) {
  const key = String(body.key || "").trim();
  const v = verifyLicenseKey(key);
  if (!v.valid) {
    const reasonText = {
      empty: "请填写会员码", format: "会员码格式不正确", invalid: "会员码内容无效",
      signature: "会员码校验失败(不是本工具签发的)", expired: "会员码已过期",
    }[v.reason] || "会员码无效";
    json(res, 400, { ok: false, error: reasonText });
    return;
  }
  await writeLicense({ key, activatedAt: Date.now() });
  json(res, 200, { ok: true, ...licenseStatus({ key }) });
}

async function apiLicenseDeactivate(res) {
  const { rm } = await import("node:fs/promises");
  await rm(LICENSE_FILE, { force: true });
  json(res, 200, { ok: true, activated: false, valid: false });
}

/* ============================ API 路由 ============================ */

async function apiParse(res, body) {
  const { items } = await handleParse(body);
  json(res, 200, { ok: true, items });
}

async function apiPreview(res, body) {
  const { engine, senders } = await makeEngine(body, {});
  const items = (body.items || []).map((it) => ({
    row: it.row ?? 0, to: it.to, amount: Number(it.amount),
    remark: it.remark ?? "", walletIndex: it.walletIndex ?? -1,
  }));
  if (!items.length) throw new Error("名单为空, 请先解析或填写转账名单");
  validateItems(items);

  await engine.init();
  engine.assignSenders(senders, items);

  // 余额检查(失败也返回明细, 由前端展示)
  let balanceOk = true, balanceError = "";
  try {
    balanceOk = body.skipBalanceCheck || await engine.checkBalances(items);
  } catch (e) {
    balanceOk = false;
    balanceError = e?.shortMessage || e?.message || String(e);
  }

  const plan = items.map((it) => ({
    row: it.row, from: it.sender.address, to: it.to, amount: it.amount,
    remark: it.remark, walletIndex: it.walletIndex,
  }));
  json(res, 200, {
    ok: true,
    wallets: senders.map((s) => ({ index: s.index, address: s.address })),
    plan,
    total: Math.round(items.reduce((s, i) => s + i.amount, 0) * 1e8) / 1e8,
    balanceOk, balanceError,
  });
}

async function apiSend(res, body) {
  if (activeSendJob) {
    json(res, 409, { ok: false, error: "已有转账任务在进行中, 请等待完成" });
    return;
  }

  const items = (body.items || []).map((it) => ({
    row: it.row ?? 0, to: it.to, amount: Number(it.amount),
    remark: it.remark ?? "", walletIndex: it.walletIndex ?? -1,
  }));
  if (!items.length) throw new Error("名单为空");

  const jobId = randomUUID();
  const job = {
    id: jobId,
    status: "running",
    logs: [],
    results: [],
    done: 0,
    total: items.length,
    startedAt: Date.now(),
    finishedAt: null,
    error: "",
  };
  jobs.set(jobId, job);
  activeSendJob = jobId;

  const run = (async () => {
    const hooks = {
      onLog: (text) => job.logs.push(`[${new Date().toLocaleTimeString()}] ${text}`),
    };
    const { engine, senders } = await makeEngine(body, hooks);
    validateItems(items);
    await engine.init();
    engine.assignSenders(senders, items);

    const balanceOk = body.skipBalanceCheck || await engine.checkBalances(items);
    if (!balanceOk) throw new Error("存在余额不足的发送钱包, 已中止");

    const results = await engine.runSends(items, (result, done, total) => {
      job.results.push(result);
      job.done = done;
      job.total = total;
    });
    job.status = "done";
    job.finishedAt = Date.now();
    job.results = results;
  })().catch((e) => {
    job.status = "failed";
    job.error = e?.shortMessage || e?.message || String(e);
    job.finishedAt = Date.now();
  }).finally(() => {
    if (activeSendJob === jobId) activeSendJob = null;
  });

  json(res, 200, { ok: true, jobId });
}

function apiJob(res, jobId) {
  const job = jobs.get(jobId);
  if (!job) { json(res, 404, { ok: false, error: "任务不存在" }); return; }
  json(res, 200, {
    ok: true,
    status: job.status,
    logs: job.logs.slice(-200),
    results: job.results,
    done: job.done,
    total: job.total,
    error: job.error,
    finishedAt: job.finishedAt,
  });
}

/* ============================ 静态资源 ============================ */

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

async function serveStatic(res, pathname) {
  const rel = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const filePath = join(__dirname, "public", rel);
  if (!filePath.startsWith(join(__dirname, "public"))) { json(res, 403, { ok: false, error: "禁止访问" }); return; }
  try {
    const data = await readFile(filePath);
    res.writeHead(200, { "content-type": MIME[extname(filePath).toLowerCase()] || "application/octet-stream" });
    res.end(data);
  } catch {
    res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    res.end("404 Not Found");
  }
}

/* ============================ 启动 ============================ */

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    // 会员拦截: 除会员接口外, 其余 /api/* 需要有效会员
    if (url.pathname.startsWith("/api/") && !url.pathname.startsWith("/api/license/")) {
      const st = licenseStatus(await readLicense());
      if (!st.valid) {
        json(res, 403, { ok: false, error: st.activated ? "会员已过期, 请重新激活" : "需要有效的会员密钥才能使用本工具", license: true });
        return;
      }
    }
    if (req.method === "POST" && url.pathname === "/api/parse") {
      return await apiParse(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/preview") {
      return await apiPreview(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/send") {
      return await apiSend(res, await readBody(req));
    }
    if (req.method === "GET" && url.pathname.startsWith("/api/job/")) {
      return apiJob(res, decodeURIComponent(url.pathname.slice("/api/job/".length)));
    }
    if (req.method === "POST" && url.pathname === "/api/wallets/generate") {
      return await apiWalletsGenerate(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/wallets/import") {
      return await apiWalletsImport(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/wallets/balances") {
      return await apiWalletsBalances(res, await readBody(req));
    }
    if (req.method === "GET" && url.pathname === "/api/wallets/list") {
      return await apiWalletsList(res);
    }
    if (req.method === "POST" && url.pathname === "/api/wallets/save") {
      return await apiWalletsSave(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/consolidate/preview") {
      return await apiConsolidatePreview(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/consolidate/send") {
      return await apiConsolidateSend(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/swap/preview") {
      return await apiSwapPreview(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/swap/send") {
      return await apiSwapSend(res, await readBody(req));
    }
    if (req.method === "GET" && url.pathname === "/api/license/status") {
      return await apiLicenseStatus(res);
    }
    if (req.method === "POST" && url.pathname === "/api/license/activate") {
      return await apiLicenseActivate(res, await readBody(req));
    }
    if (req.method === "POST" && url.pathname === "/api/license/deactivate") {
      return await apiLicenseDeactivate(res);
    }
    if (req.method === "GET") {
      return await serveStatic(res, url.pathname);
    }
    json(res, 404, { ok: false, error: "Not Found" });
  } catch (e) {
    const msg = e?.shortMessage || e?.message || String(e);
    json(res, 400, { ok: false, error: msg });
  }
});

server.listen(PORT, HOST, () => {
  console.log("");
  console.log("  BNB 批量转账 APP 已启动");
  console.log(`  请用浏览器打开:  http://${HOST}:${PORT}`);
  console.log("  提示: 密钥只在内存中使用, 服务仅监听本机; 关闭窗口即退出。");
  console.log("");
});
