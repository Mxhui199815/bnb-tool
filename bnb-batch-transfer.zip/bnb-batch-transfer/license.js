/**
 * 会员密钥校验(APP 内置公钥, 本地离线校验)
 * 生成会员码请使用独立的「会员密钥生成器」(license-admin), 私钥不在此处。
 */
import { createPublicKey, verify } from "node:crypto";

export const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA5KF/FP5RJeoCa0T/oz70vRDQ1OpjTctbLLUnA1sEYC0=
-----END PUBLIC KEY-----`;

export const TIERS = {
  week:  { label: "1周会员",  days: 7 },
  month: { label: "1月会员",  days: 30 },
  year:  { label: "1年会员",  days: 365 },
  life:  { label: "终生会员", days: null },
};

export function tierLabel(tier) {
  return (TIERS[tier] || {}).label || tier;
}

/** 校验会员码: 返回 { valid, payload?, reason? } */
export function verifyLicenseKey(keyStr) {
  const s = String(keyStr || "").trim();
  if (!s) return { valid: false, reason: "empty" };
  const [p, sig] = s.split(".");
  if (!p || !sig) return { valid: false, reason: "format" };
  let payload;
  try {
    payload = JSON.parse(Buffer.from(p, "base64url").toString("utf8"));
  } catch {
    return { valid: false, reason: "format" };
  }
  if (!payload || payload.v !== 1 || !TIERS[payload.tier]) return { valid: false, reason: "invalid" };
  try {
    const ok = verify(null, Buffer.from(p, "utf8"), createPublicKey(PUBLIC_KEY), Buffer.from(sig, "base64url"));
    if (!ok) return { valid: false, reason: "signature" };
  } catch {
    return { valid: false, reason: "signature" };
  }
  if (payload.tier !== "life" && payload.exp && Date.now() > payload.exp * 1000) {
    return { valid: false, reason: "expired", payload };
  }
  return { valid: true, payload };
}

/** 剩余毫秒数(life 返回 null) */
export function remainingMs(payload) {
  if (payload.tier === "life" || !payload.exp) return null;
  return payload.exp * 1000 - Date.now();
}
