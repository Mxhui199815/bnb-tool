# BNB 批量转账脚本 (BSC)

按 Excel / CSV 名单,从助记词派生地址或私钥钱包**逐笔**发送原生 BNB(BSC 主网 / 测试网)。

## 🖥️ 网页版 APP(图形界面)

不想敲命令?本地网页版 APP 提供图形界面:上传/粘贴名单、填密钥、干跑检查、一键转账、实时进度和结果表格。

### 启动

```bash
npm run app        # 或 node app-server.js
```

然后在浏览器打开 **http://127.0.0.1:3000**

> 服务默认只监听本机(127.0.0.1),密钥仅在内存中使用、不落盘、不上传。
> 关闭终端(或按 Ctrl+C)即停止服务。

### 界面操作(顶部导航菜单切换页面)

- **💸 批量转账** — 页面自上而下:发送钱包 → 转账参数 → 转账名单 → 检查与发送;
  名单可「＋ 从管理列表添加」一键带入「钱包管理」的钱包作为收款人;发送钱包也可直接选「管理列表」(本会话已导入私钥)
- **🔄 薄饼交易** — 填写代币地址/数量/方向(买或卖)/滑点,「交易检查」看余额/授权/预计输出,「执行交易」批量买卖(卖单自动先授权 Router);发送钱包支持「管理列表」勾选, 实时进度与结果 CSV
- **🔐 创建冷钱包** — 新助记词派生 / 已有助记词派生 / 独立私钥, 本地生成, 可加入管理列表或导出含私钥 CSV(带强警告)
- **🗂️ 钱包管理** — 助记词/私钥/CSV 批量导入, 打标签、批量查余额、复制地址/私钥、导出、清空; 列表自动保存到 data/wallets.json(私钥不落盘)
- **🧹 资产归集** — 选择源钱包(助记词/私钥/管理列表)与目标地址;「管理列表」来源可**勾选**要归集的钱包(标注哪些有私钥);「归集检查」预览每钱包余额/手续费/可归集金额, 确认后「执行归集」, 后台任务带进度与结果 CSV

> RPC 节点和链 ID 在顶部全局配置, 所有页面共用。

## 特性

- 🔐 **批量创建冷钱包**: 新助记词派生 / 已有助记词派生 / 独立私钥, 本地生成, 可导出含私钥 CSV(带强警告)
- 🗂️ **批量管理钱包**: 助记词/私钥/CSV 批量导入, 打标签、批量查余额、复制地址/私钥、导出、本地持久化(地址+标签, 私钥不落盘)
- 🧹 **批量资产归集**: 把多个源钱包(助记词派生/私钥/管理列表)的 BNB 一次性归集到目标地址, 先预览余额/手续费/可归集金额, 后台任务带进度与结果 CSV
- 🔄 **薄饼交易**: 批量在 PancakeSwap 买卖(Buy=BNB→Token / Sell=Token→BNB), 内置 Router/WBNB 合约地址与 ABI; 支持滑点、输出预估、卖出自动授权、批量执行、结果 CSV
- 📋 名单支持 **CSV / XLSX**,列名自动识别:`to`(收款地址)、`amount`(BNB 数量)、可选 `remark`(备注)、可选 `wallet_index`(指定发送钱包)
- 🔑 钱包来源:助记词(BIP44 `m/44'/60'/0'/0/{index}`)或私钥列表,可**多发送钱包轮询**分散发送
- 🛡️ 安全设计:默认 **dry-run** 只打印计划;发送前**余额检查**、地址/金额校验、重复收款人提醒;gas 费**上限保护**;发送需 `--send` + 交互确认(或 `--yes`)
- 🔁 自动管理 nonce、失败自动重试并上浮 gas 费;公共 RPC 节点**自动故障转移**(逗号分隔多节点)
- 📄 结果输出 CSV(每笔 tx hash、区块、状态、错误),带 BOM 可直接用 Excel 打开

## 🔑 会员制

本工具采用**会员制**,需要输入会员密钥才能登录使用。

- **4 档会员**:1周 / 1月 / 1年 / 终生
- 密钥由管理员用独立的「会员密钥生成器」签发(见 license-admin 文件夹, 管理员专用, 勿外发)
- 激活后顶部显示会员徽章与剩余时间; 到期自动锁定, 需新密钥重新激活
- 本地离线校验(内置公钥), 断网也能使用

## 安装

需要 Node.js ≥ 18。

```bash
cd bnb-batch-transfer
npm install        # 或 pnpm install
```

> 已安装好依赖的副本位于 `work/bnb-batch-transfer/`,可直接运行。

## 名单格式

`sample-list.csv` 示例:

| to | amount | remark | wallet_index |
|---|---|---|---|
| 0x8894E0a0c962CB723c1976a4421c95949bE2D4E3 | 0.01 | 币安热钱包 | 0 |
| 0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045 | 0.02 | vitalik.eth | 1 |
| 0x000000000000000000000000000000000000dEaD | 0.005 | 销毁地址 | |

- `to`、`amount` 必填;金额 > 0,允许千分位(如 `1,000.5`)
- `wallet_index` 留空则**轮询**使用第 0 个发送钱包开始(配合 `--senders`)
- 列名支持别名:地址(address/recipient/收款地址…)、金额(value/金额…)、备注(memo/备注…)、序号(sender/index/序号…)
- 无表头 CSV 也支持,按 `to,amount,remark` 顺序

## 使用

### 1. 先干跑检查(不广播)

```bash
node transfer.js --list sample-list.csv --dry-run --senders 2
```

### 2. 真正发送

```bash
# 方式 A: 助记词(建议用环境变量或 secrets.json, 别写进命令行历史)
node transfer.js --list list.csv --mnemonic "你的助记词" --send --senders 2

# 方式 B: 私钥列表
node transfer.js --list list.csv --private-keys "0x私钥1,0x私钥2" --send

# 方式 C: secrets.json
node transfer.js --list list.csv --secrets secrets.json --send
```

发送前会打印计划并提示输入 `yes` 确认;非交互式环境(脚本/定时任务)必须显式加 `--yes`。

### 3. 测试网试跑

```bash
node transfer.js --list sample-list.csv --rpc https://data-seed-prebsc-1-s1.bnbchain.org:8545 --chain-id 97 --mnemonic "..." --dry-run
```

## 常用参数

| 参数 | 说明 | 默认 |
|---|---|---|
| `--list <path>` | 转账名单(CSV/XLSX),必填 | — |
| `--mnemonic "..."` / `--private-keys "0x..,0x.."` / `--secrets <json>` | 钱包来源(三选一) | 环境变量 `MNEMONIC` / `PRIVATE_KEYS` |
| `--rpc <url,...>` | RPC 节点,逗号分隔自动故障转移 | BSC 主网公共节点 |
| `--chain-id <n>` | 链 ID | 56(测试网 97) |
| `--senders <n>` | 使用的发送钱包数(轮询) | 1 |
| `--start-index <n>` | 助记词派生起始序号 | 0 |
| `--dry-run` | 只检查不广播(默认) | 开 |
| `--send` | 真正广播 | 关 |
| `--yes` | 跳过确认提示 | 关 |
| `--max-gas-price <gwei>` | gas 费上限 | 10 |
| `--fee-mode <legacy\|eip1559>` | 费用模式 | legacy |
| `--gas-limit <n>` | 每笔 gas | 21000 |
| `--confirmations <n>` | 等待确认数(0=广播即记录) | 1 |
| `--max-retries <n>` | 单笔失败重试次数 | 3 |
| `--fee-bump-percent <n>` | 重试 gas 上浮百分比 | 10 |
| `--output <path>` | 结果 CSV 路径 | `results-<时间戳>.csv` |
| `--skip-balance-check` | 跳过余额检查(仅排错用) | 关 |

完整帮助:`node transfer.js --help`

## ⚠️ 安全注意事项

1. **密钥保护**:助记词/私钥只通过环境变量或 `secrets.json` 传入,不要写进脚本/命令行历史/提交到 git。`secrets.json` 已被 `.gitignore` 排除。
2. **先小额试发**:先用 `--dry-run` 检查计划,再用测试网或极小金额在主网试发 1~2 笔。
3. **gas 上限**:`--max-gas-price` 默认 10 gwei,防止节点异常时费用失控;拥堵时按需调高。
4. **RPC 节点**:默认公共节点仅供体验;大额转账建议使用自建或可信的 RPC(私有节点),避免公共节点故障/作恶。
5. **失败重试语义**:失败重试会用相同 nonce + 更高 gas 替换 pending 交易;若提示 nonce 冲突会自动重新同步 nonce。跑完请核对结果 CSV,未成功的笔数用 `--start-index`/筛选名单补发。

## 离线测试(可选)

自带 `mock-rpc.mjs` 本地模拟 BSC 节点(不连真实网络、不花钱),可验证完整发送链路:

```bash
node mock-rpc.mjs            # 终端 1: 启动模拟节点 http://127.0.0.1:8545
# 终端 2:
node transfer.js --list sample-list.csv --rpc http://127.0.0.1:8545 \
  --private-keys "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80,0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d" \
  --senders 2 --send --yes
```
